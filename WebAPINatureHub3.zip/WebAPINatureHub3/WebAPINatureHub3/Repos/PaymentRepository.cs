﻿namespace WebAPINatureHub3.Repos
{
    using WebAPINatureHub3.Models;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.EntityFrameworkCore;

    public class PaymentRepository : IRepository<Payment>
    {
        private readonly NatureHub3Context _context;

        public PaymentRepository(NatureHub3Context context)
        {
            _context = context;
        }

        // Get all payments from the database
        public IEnumerable<Payment> GetAll()
        {
            return _context.Payments
                .Include(p => p.User)   // Including User details associated with payment
                .ToList();
        }

        // Get a payment by its ID
        public Payment GetById(int id)
        {
            return _context.Payments
                .Include(p => p.User)  // Including User details
                .FirstOrDefault(p => p.PaymentId == id);
        }

        // Add a new payment
        public void Add(Payment payment)
        {
            _context.Payments.Add(payment);
            _context.SaveChanges();
        }

        // Update an existing payment
        public void Update(Payment payment)
        {
            _context.Payments.Update(payment);
            _context.SaveChanges();
        }

        // Delete a payment by its ID
        public void Delete(int id)
        {
            var payment = _context.Payments.Find(id);
            if (payment != null)
            {
                _context.Payments.Remove(payment);
                _context.SaveChanges();
            }
        }

        // Get payments for a specific user
        public IEnumerable<Payment> GetByUserId(int userId)
        {
            return _context.Payments
                .Where(p => p.UserId == userId)
                .Include(p => p.User)  // Including User details
                .ToList();
        }
    }
}
