﻿namespace WebAPINatureHub3.HealthTipsDtos
{
    public class ReadHealthTipDTO
    {
        public int TipId { get; set; }
        public string TipTitle { get; set; } = null!;
        public string? TipDescription { get; set; }
        public byte[] HealthTipsimg { get; set; }  // This could be used for displaying the image
        public int CategoryId { get; set; }
    }
}
