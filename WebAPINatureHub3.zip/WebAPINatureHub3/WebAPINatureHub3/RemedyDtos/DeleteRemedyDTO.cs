﻿namespace WebAPINatureHub3.RemedyDtos
{
    public class DeleteRemedyDTO
    {

        public int RemedyId { get; set; }
    }
}
